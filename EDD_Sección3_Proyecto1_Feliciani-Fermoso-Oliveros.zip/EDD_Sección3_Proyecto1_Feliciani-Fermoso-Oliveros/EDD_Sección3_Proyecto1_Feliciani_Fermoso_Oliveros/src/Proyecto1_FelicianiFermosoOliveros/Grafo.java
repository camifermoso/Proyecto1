/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto1_FelicianiFermosoOliveros;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 * @Descripcion: Clase Grafo
 * @author Santiago
 * @retorna Grafo
 * @version 23/02/2024
 */
public class Grafo {

    public int maximo;
    public int cantidad;
    public Lista[] vertices;
    public int primero;
    public int ultima;
    public Hormiga menor;

    public Grafo(int max) {
        this.maximo = max;
        this.cantidad = 0;
        this.vertices = new Lista[max];
        int primero = 0;
        int ultima = 3;
        for (int i = 0; i < max; i++) {
            this.vertices[i] = new Lista();
        }
    }

    //
    public void Insertar(String dato) {
        Nodo nuevo = new Nodo(dato, 0);
        if (this.cantidad < 20) {
            if (this.buscar(dato) == null) {
                if (this.cantidad != this.maximo) {

                    for (int i = 0; i < this.maximo; i++) {
                        if (this.vertices[i].primero == null) {

                            this.vertices[i].InsertarFinal(nuevo);
                            break;
                        }
                    }

                    this.cantidad++;
                } else {
                    Lista[] nueva = new Lista[maximo + 1];
                    for (int i = 0; i < this.maximo; i++) {
                        nueva[i].InsertarFinal(this.vertices[i].primero);
                    }
                    nueva[maximo].InsertarFinal(nuevo);
                    this.vertices = nueva;
                    this.cantidad++;
                }
            } else {
                JOptionPane.showMessageDialog(null, "Esa ciudad ya existe");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Haz llegado a la maxia cantidad de ciudades");
        }
    }

    //
    public void Eliminar(String dato) {
        if (this.cantidad != 0) {
            for (int i = 0; i < this.maximo; i++) {
                if (this.vertices[i].primero != null && this.vertices[i].primero.getDato().equals(dato)) {
                    this.vertices[i].primero = null;
                    this.cantidad--;
                } else {
                    this.vertices[i].EliminarGeneral(dato);
                }

            }
        }
    }

    //
    public void InsertarLista(String dato, String dato2, double dist) {
        if (this.cantidad != 0) {
            if (!this.buscar(dato2).Buscar(dato)) {
                for (int i = 0; i < this.maximo; i++) {
                    if (this.vertices[i].primero != null && this.vertices[i].primero.getDato().equals(dato)) {
                        this.vertices[i].InsertarFinal(new Nodo(dato2, dist));
                    } else if (this.vertices[i].primero != null && this.vertices[i].primero.getDato().equals(dato2)) {
                        this.vertices[i].InsertarFinal(new Nodo(dato, dist));
                    }

                }
            }
        }
    }

    //
    public String Imprimir() {
        String lista = "";
        if (this.cantidad != 0) {
            for (int i = 0; i < this.maximo; i++) {
                if (this.vertices[i].primero != null) {
                    lista += this.vertices[i].ImprimirLista() + "\n";
                }
            }
        }
//        System.out.println(lista);
        return lista;
    }

    //
    public Lista buscar(String nombre) {
        for (int i = 0; i < this.maximo; i++) {
            if (this.vertices[i].primero != null &&this.vertices[i].primero.getDato().equals(nombre)) {
                return this.vertices[i];
            }
        }
        return null;
    }

    //
    public double Sumatoria(int posicion, boolean[] visitados, int alpha, int beta) {
        double T = 1;
        double sum = 0;
        for (int i = 0; i < this.maximo; i++) {

            if (i != posicion && !visitados[i] && this.vertices[i].primero != null && this.vertices[posicion].Buscar(this.vertices[i].primero.getDato())) {

//                System.out.println("----FEROMONAS ---> " + this.vertices[posicion].Buscar2(this.vertices[i].primero.getDato()).getFeromonas());
//                System.out.println("----DISTANCIA---> " + this.vertices[posicion].Buscar2(this.vertices[i].primero.getDato()).getDistancia());
                sum += Math.pow(this.vertices[posicion].Buscar2(this.vertices[i].primero.getDato()).getFeromonas(), alpha) * Math.pow(1 / this.vertices[posicion].Buscar2(this.vertices[i].primero.getDato()).getDistancia(), beta);
//                System.out.println("Sumatoria --- > "+sum);
            } else {
//                System.out.println("no pasa");
            }
        }
        return sum;

    }

    //
    public double calcularProb(int posicion, boolean[] visitados, int posicion2, int alpha, int beta) {
        double sumatoria = this.Sumatoria(posicion, visitados, alpha, beta);
        return (Math.pow(this.vertices[posicion].Buscar2(this.vertices[posicion2].primero.getDato()).getFeromonas(), alpha) * Math.pow(1 / this.vertices[posicion].Buscar2(this.vertices[posicion2].primero.getDato()).getDistancia(), beta)) / sumatoria;
    }

    //
    public void Recorrer(Hormiga h, int posicion, boolean[] visitados, int alpha, int beta) {
        visitados[posicion] = true;
        h.recorrido += this.vertices[posicion].primero.getDato() + ",";
        Random r = new Random();
        double randomnum = r.nextDouble();
        double probAcumulada = 0;
        if (posicion != this.ultima) {

            for (int i = 0; i < this.maximo; i++) {
                if (i != posicion && !visitados[i] && this.vertices[i].primero != null && this.vertices[posicion].Buscar(this.vertices[i].primero.getDato())) {
                    probAcumulada += this.calcularProb(posicion, visitados, i, alpha, beta);
//                    System.out.println("Probabilidad Acumulada: " + probAcumulada);
                }
                if (probAcumulada > randomnum) {
                    h.distancia += this.vertices[posicion].Buscar2(this.vertices[i].primero.getDato()).getDistancia();
//                    System.out.println("Distancia Recorrida: ---> " + h.distancia);
                    this.Recorrer(h, i, visitados, alpha, beta);
                    break;
                }

            }
        }
    }

    //
    public Hormiga Profundidad(int alpha, int beta) {
        boolean visitados[] = new boolean[maximo];
        Hormiga h = new Hormiga();
        for (int i = 0; i < this.maximo; i++) {
            visitados[i] = false;
        }
        Recorrer(h, primero, visitados, alpha, beta);
        this.actualizarAcumuladoFeromonas(h);
        if (this.menor == null || h.distancia < menor.distancia) {
            this.menor = h;
        }
        return h;
    }

    //
    public void iniciarFeromonas() {
        for (int i = 0; i < this.maximo; i++) {
            Nodo aux = this.vertices[i].primero;
            if (aux != null) {
                aux = aux.getSiguiente();
                while (aux != null) {
                    aux.setFeromonas(1 / (double) this.cantidad);

                    aux.setAcumulado(0);
                    aux = aux.getSiguiente();
                }
            }
        }
    }

    //
    public void actualizarAcumuladoFeromonas(Hormiga h) {
        String[] ciudades = h.recorrido.split(",");
        for (int i = 0; i < ciudades.length; i++) {
            if (i + 1 < ciudades.length) {
                this.buscar(ciudades[i]).Buscar2(ciudades[i + 1]).setAcumulado(this.buscar(ciudades[i]).Buscar2(ciudades[i + 1]).getAcumulado() + 1 / h.distancia);
                this.buscar(ciudades[i + 1]).Buscar2(ciudades[i]).setAcumulado(this.buscar(ciudades[i + 1]).Buscar2(ciudades[i]).getAcumulado() + 1 / h.distancia);
            }
        }
    }

    //
    public void cambiarCiudadPartida(String dato) {
        if (this.cantidad != 0) {
            for (int i = 0; i < this.maximo; i++) {
                if (this.vertices[i].primero != null && this.vertices[i].primero.getDato().equals(dato)) {
                    this.primero = i;
                }
            }
        }
    }

    //
    public void cambiarCiudadLlegada(String dato) {
        if (this.cantidad != 0) {
            for (int i = 0; i < this.maximo; i++) {
                if (this.vertices[i].primero != null && this.vertices[i].primero.getDato().equals(dato)) {
                    this.ultima = i;
                }
            }
        }
    }

    //
    public void actualizarFeromonasFinal(double rho) {
        for (int i = 0; i < this.maximo; i++) {
            Nodo aux = this.vertices[i].primero;
            if (aux != null) {
                aux = aux.getSiguiente();
                while (aux != null) {
                    aux.setFeromonas(aux.getFeromonas() * (1 - rho) + aux.getAcumulado());
//                    System.out.println("Feromonas Actualizadas --> " + aux.getFeromonas());
                    aux.setAcumulado(0);
                    aux = aux.getSiguiente();
                }
            }
        }
    }

    public String printFeromonas() {
        String fer = "";
        for (int i = 0; i < this.maximo; i++) {
            Nodo aux = this.vertices[i].primero;
            if (aux != null) {
                aux = aux.getSiguiente();
                while (aux != null) {
                    fer += this.vertices[i].primero.getDato() + " - " + aux.getDato() + " -> " + aux.getFeromonas() + " feromonas\n";
                    aux = aux.getSiguiente();
                }
            }
        }
        return fer;

    }
}
