/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto1_FelicianiFermosoOliveros;

/**
 * @Descripcion: Clase Hormiga
 * @author Santiago
 * @retorna Hormiga
 * @version 23/02/2024
 */
public class Hormiga {

    public String recorrido;
    public double distancia;

    public Hormiga() {
        recorrido = "";
        distancia = 0;
    }
}
