/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Proyecto1_FelicianiFermosoOliveros;

import interfaz.Home;
import org.graphstream.graph.Edge;
import org.graphstream.graph.EdgeRejectedException;
import org.graphstream.graph.ElementNotFoundException;
import org.graphstream.graph.Graph;
import org.graphstream.graph.IdAlreadyInUseException;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;
/**
 *
 * @author santi
 */
public class EDD_Seccion3_Proyecto1_Feliciani_Fermoso_Oliveros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Grafo grafo = new Grafo(20);
//        grafo.Insertar("1");
//        grafo.Insertar("2");
//        grafo.Insertar("3");
//        grafo.Insertar("4");
//
//        grafo.InsertarLista("2", "3", 3);
//        grafo.InsertarLista("1", "4", 6);
//        grafo.InsertarLista("1", "3", 7);
//        grafo.InsertarLista("2", "4", 1);
//        grafo.iniciarFeromonas();
//        grafo.ultima = 3;
////4 
//        for (int j = 0; j < 10; j++) {
//            for (int i = 0; i < 10; i++) {
//                Hormiga a = grafo.Profundidad(1, 1);
////                System.out.println(a.recorrido);
//                grafo.actualizarAcumuladoFeromonas(a);
//            }
//            grafo.actualizarFeromonasFinal(0.5);
//        }
//Graph graph = new SingleGraph("MyGraph");
//        graph.setAttribute("ui.stylesheet", "node{shape: circle; fill-color: #5DC1B9; text-color: #000000; size: 40px;}" + "edge{size: 2px; shape: line; fill-color: #D3D3D3;}");
//        for (int i = 0; i < grafo.maximo; i++) {
//            if (grafo.vertices[i].primero != null) {
////                System.out.println("a");
//                String source = grafo.vertices[i].primero.getDato();
//                Nodo currentUser = grafo.vertices[i].primero.getSiguiente();
//                while (currentUser != null) {
//                    String target = currentUser.getDato();
////                    System.out.println("b");
//                    try {
//                        Edge edge = graph.addEdge(source + "-" + target, source, target, false);
//                        edge.setAttribute("ui.style", "fill-color: black");
//                        currentUser = currentUser.getSiguiente();
////                        System.out.println("c");
//                    } catch (EdgeRejectedException | ElementNotFoundException | IdAlreadyInUseException e) {
//                        currentUser = currentUser.getSiguiente();
//                    }
//                }
//            }
//
//        }
//        System.setProperty("org.graphstream.ui", "org.graphstream.ui.swing");
//        Viewer viewer = graph.display();
        Home ventana = new Home(grafo);
        ventana.setVisible(true);
    }
    
}
